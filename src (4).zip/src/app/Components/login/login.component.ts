import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserAccountService } from '../../Services/user-account.service';
import { User } from '../../Models/user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;

 // userAccountService: UserAccountService;

  constructor(private userAccountService: UserAccountService, private router: Router) {
    this.loginForm = new FormGroup(
      {
        email: new FormControl(null,[Validators.required, Validators.email]),
        password: new FormControl(null,[Validators.required]),
        userType: new FormControl("Retailer")
      });
  }

  ngOnInit() {
  }

  onLoginClick() {
    this.userAccountService.authenticate(this.loginForm.value.email, this.loginForm.value.password, this.loginForm.value.userType).subscribe((response) => {
      if (response != null && response.length > 0) {
        if (this.loginForm.value.userType == "Admin") {

          this.userAccountService.currentUser = new User(this.loginForm.value.email, response[0].adminName, response[0].adminID);
          console.log(response[0].adminID);
          console.log(this.userAccountService.currentUser);
          this.userAccountService.currentUserType = "Admin";
          this.userAccountService.isLoggedIn = true;
          this.router.navigate(["/admin", "home"]);
        }

        else if (this.loginForm.value.userType == "SalesPerson") {

          this.userAccountService.currentUser = new User(this.loginForm.value.email, response[0].salesPersonName, response[0].salespersonID);
          this.userAccountService.currentUserType = "SalesPerson";
          this.userAccountService.isLoggedIn = true;
          this.router.navigate(["/salesperson", "home"]);
        }

        else if (this.loginForm.value.userType == "Retailer") {

          this.userAccountService.currentUser = new User(this.loginForm.value.email, response[0].retailerName, response[0].retailerID);
          this.userAccountService.currentUserType = "Retailer";
          this.userAccountService.isLoggedIn = true;
          this.router.navigate(["/retailer", "home"]);
        }

      }
    }, (error) => {
        console.log(error);
      });
  }
}



