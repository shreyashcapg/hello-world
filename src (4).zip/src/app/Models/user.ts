export class User {
  email: string;
  name: string;
  id: string
    

  constructor(Email: string, Name: string, ID   : string) {
    this.email = Email;
    this.name = Name;
    this.id = ID;
  }

}
