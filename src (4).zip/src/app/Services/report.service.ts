import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Order } from '../Models/order';
import { OrderDetail } from '../Models/order-detail';

@Injectable({
  providedIn: 'root'
})

export class ReportService {
  constructor(private httpClient: HttpClient) {

  }

  GetAllOrders(): Observable<Order[]> {
    return this.httpClient.get<Order[]>(`/api/orders`);
  }

  GetAllOrderDetailsByOrderID(orderId: string): Observable<OrderDetail[]> {
    return this.httpClient.get<OrderDetail[]>(`/api/orderdetails?orderID=${orderId}`);
  }

}
