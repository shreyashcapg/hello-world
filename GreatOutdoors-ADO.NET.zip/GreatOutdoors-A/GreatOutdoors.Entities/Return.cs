﻿using Capgemini.GreatOutdoors.Helpers.ValidationAttributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.GreatOutdoors.Entities
{
    /// <summary>
    /// Reason of Return i.e. Wrong or Incomplete
    /// </summary>
    //public enum ReasonOfReturn { Wrong, Incomplete }

    public enum ReturnChannel
    {
        Offline, Online
    }
    

    /// <summary>
    /// Interface for Return Entity
    /// </summary>
    public interface IReturn
    {
        Guid ReturnID { get; set; }
        //ReasonOfReturn ReasonOfReturn { get; set; }
        Guid OrderID { get; set; }
        ReturnChannel ChannelOfReturn { get; set; }
        double ReturnAmount { get; set; }
        DateTime ReturnDateTime { get; set; }
        //DateTime LastModifiedDateTime { get; set; }
    }

    /// <summary>
    /// Represents Return
    /// </summary>
    public class Return : IReturn
    {
        [Required("Return ID can't be blank.")]
        public Guid ReturnID { get; set; }
        [Required("Order ID can't be blank.")]
        public Guid OrderID { get; set; }
        [Required("Channel can't be blank.")]
        public ReturnChannel ChannelOfReturn { get; set; }
        [Required("Amount can't be blank.")]
        public double ReturnAmount { get; set; }
        
        //[Required("Return quantity cannot be blank")]


        /*[Required("Unit Price cannot be blank")]
        public double UnitPrice { get; set; }*/

        public DateTime ReturnDateTime { get; set; }
        //public DateTime LastModifiedDateTime { get; set; }

        /*Constructor*/
        public Return()
        {
            ReturnID = default(Guid);
            OrderID = default(Guid);
            ChannelOfReturn = ReturnChannel.Online;
            
            ReturnAmount = default(double);
            ReturnDateTime = default(DateTime);
        }


    }

}


