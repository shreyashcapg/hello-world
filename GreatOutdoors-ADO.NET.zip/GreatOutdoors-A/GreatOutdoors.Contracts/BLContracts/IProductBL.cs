﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Capgemini.GreatOutdoors.Entities;

namespace Capgemini.GreatOutdoors.Contracts.BLContracts
{
    public interface IProductBL : IDisposable
    {
        Task<bool> AddProductBL(Product newProduct);
        Task<List<Product>> GetAllProductsBL();
        Task<Product> GetProductByProductIDBL(Guid searchProductID);
        Task<List<Product>> GetProductsByNameBL(string ProductName);
        Task<List<Product>> GetProductByCategoryBL(Category CategoryName);
        Task<bool> UpdateProductBL(Product updateProduct);
        Task<bool> DeleteProductBL(Guid deleteProductID);
        Task<bool> UpdateProductStockBL(Product updateProduct);

    }
}


