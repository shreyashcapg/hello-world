import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AdminRoutingModule } from './admin-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { AddressComponent } from './retailer-address/retailer-address.component'

@NgModule({
  declarations: [
    AdminHomeComponent,
    AddressComponent
    //SuppliersComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AdminRoutingModule,
    HttpClientModule
  ],
  exports: [
    AdminRoutingModule,
    AdminHomeComponent,
    AddressComponent
    //SuppliersComponent
  ]
})
export class AdminModule { }

