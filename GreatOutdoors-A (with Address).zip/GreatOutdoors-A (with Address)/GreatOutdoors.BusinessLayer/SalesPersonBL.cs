﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Capgemini.GreatOutdoors.Contracts.DALContracts;
using Capgemini.GreatOutdoors.DataAccessLayer;
using Capgemini.GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.Exceptions;
using Capgemini.GreatOutdoors.Contracts.BLContracts;


namespace Capgemini.GreatOutdoors.BusinessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating, deleting SalesPersons from SalesPersons collection.
    /// </summary>
    public class SalesPersonBL : BLBase<SalesPerson>, ISalesPersonBL, IDisposable
    {
        //fields
        SalesPersonDALBase SalesPersonDAL;
        OrderBL orderbl = new OrderBL();


        /// <summary>
        /// Constructor.
        /// </summary>
        public SalesPersonBL()
        {
            this.SalesPersonDAL = new SalesPersonDAL();
        }

        /// <summary>
        /// Validations on data before adding or updating.
        /// </summary>
        /// <param name="entityObject">Represents object to be validated.</param>
        /// <returns>Returns a boolean value, that indicates whether the data is valid or not.</returns>
        protected async override Task<bool> Validate(SalesPerson entityObject)
        {
            //Create string builder
            StringBuilder sb = new StringBuilder();
            bool valid = await base.Validate(entityObject);

            //Email is Unique
            var existingObject = await GetSalesPersonByEmailBL(entityObject.Email);
            if (existingObject != null && existingObject?.SalesPersonID != entityObject.SalesPersonID)
            {
                valid = false;
                sb.Append(Environment.NewLine + $"Email {entityObject.Email} already exists");
            }

            if (valid == false)
                throw new GreatOutdoorsException(sb.ToString());
            return valid;
        }

        /// <summary>
        /// Adds new SalesPerson to SalesPersons collection.
        /// </summary>
        /// <param name="newSalesPerson">Contains the SalesPerson details to be added.</param>
        /// <returns>Determinates whether the new SalesPerson is added.</returns>
        public async Task<bool> AddSalesPersonBL(SalesPerson newSalesPerson)
        {
            bool SalesPersonAdded = false;
            try
            {
                if (await Validate(newSalesPerson))
                {
                    await Task.Run(() =>
                    {
                        this.SalesPersonDAL.AddSalesPersonDAL(newSalesPerson);
                        SalesPersonAdded = true;
                    });
                }
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return SalesPersonAdded;
        }

        /// <summary>
        /// Gets all SalesPersons from the collection.
        /// </summary>
        /// <returns>Returns list of all SalesPersons.</returns>
        public async Task<List<SalesPerson>> GetAllSalesPersonsBL()
        {
            List<SalesPerson> SalesPersonsList = null;
            try
            {
                await Task.Run(() =>
                {
                    SalesPersonsList = SalesPersonDAL.GetAllSalesPersonsDAL();
                });
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return SalesPersonsList;
        }

        /// <summary>
        /// Gets SalesPerson based on SalesPersonID.
        /// </summary>
        /// <param name="searchSalesPersonID">Represents SalesPersonID to search.</param>
        /// <returns>Returns SalesPerson object.</returns>
        public async Task<SalesPerson> GetSalesPersonBySalesPersonIDBL(Guid searchSalesPersonID)
        {
            SalesPerson matchingSalesPerson = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingSalesPerson = SalesPersonDAL.GetSalesPersonBySalesPersonIDDAL(searchSalesPersonID);
                });
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return matchingSalesPerson;
        }

        /// <summary>
        /// Gets SalesPerson based on SalesPersonName.
        /// </summary>
        /// <param name="SalesPersonName">Represents SalesPersonName to search.</param>
        /// <returns>Returns SalesPerson object.</returns>
        public async Task<List<SalesPerson>> GetSalesPersonsByNameBL(string SalesPersonName)
        {
            List<SalesPerson> matchingSalesPersons = new List<SalesPerson>();
            try
            {
                await Task.Run(() =>
                {
                    matchingSalesPersons = SalesPersonDAL.GetSalesPersonsByNameDAL(SalesPersonName);
                });
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return matchingSalesPersons;
        }

        /// <summary>
        /// Gets SalesPerson based on Email and Password.
        /// </summary>
        /// <param name="email">Represents SalesPerson's Email Address.</param>
        /// <returns>Returns SalesPerson object.</returns>
        public async Task<SalesPerson> GetSalesPersonByEmailBL(string email)
        {
            SalesPerson matchingSalesPerson = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingSalesPerson = SalesPersonDAL.GetSalesPersonByEmailDAL(email);
                });
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return matchingSalesPerson;
        }

        /// <summary>
        /// Gets SalesPerson based on Password.
        /// </summary>
        /// <param name="email">Represents SalesPerson's Email Address.</param>
        /// <param name="password">Represents SalesPerson's Password.</param>
        /// <returns>Returns SalesPerson object.</returns>
        public async Task<SalesPerson> GetSalesPersonByEmailAndPasswordBL(string email, string password)
        {
            SalesPerson matchingSalesPerson = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingSalesPerson = SalesPersonDAL.GetSalesPersonByEmailAndPasswordDAL(email, password);
                });
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return matchingSalesPerson;
        }

        /// <summary>
        /// Updates SalesPerson based on SalesPersonID.
        /// </summary>
        /// <param name="updateSalesPerson">Represents SalesPerson details including SalesPersonID, SalesPersonName etc.</param>
        /// <returns>Determinates whether the existing SalesPerson is updated.</returns>
        public async Task<bool> UpdateSalesPersonBL(SalesPerson updateSalesPerson)
        {
            bool SalesPersonUpdated = false;
            try
            {
                if ((await Validate(updateSalesPerson)) && (await GetSalesPersonBySalesPersonIDBL(updateSalesPerson.SalesPersonID)) != null)
                {
                    this.SalesPersonDAL.UpdateSalesPersonDAL(updateSalesPerson);
                    SalesPersonUpdated = true;
                }
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return SalesPersonUpdated;
        }

        /// <summary>
        /// Deletes SalesPerson based on SalesPersonID.
        /// </summary>
        /// <param name="deleteSalesPersonID">Represents SalesPersonID to delete.</param>
        /// <returns>Determinates whether the existing SalesPerson is updated.</returns>
        public async Task<bool> DeleteSalesPersonBL(Guid deleteSalesPersonID)
        {
            bool SalesPersonDeleted = false;
            try
            {
                await Task.Run(() =>
                {
                    SalesPersonDeleted = SalesPersonDAL.DeleteSalesPersonDAL(deleteSalesPersonID);
                });
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return SalesPersonDeleted;
        }

        /// <summary>
        /// Updates SalesPerson's password based on SalesPersonID.
        /// </summary>
        /// <param name="updateSalesPerson">Represents SalesPerson details including SalesPersonID, Password.</param>
        /// <returns>Determinates whether the existing SalesPerson's password is updated.</returns>
        public async Task<bool> UpdateSalesPersonPasswordBL(SalesPerson updateSalesPerson)
        {
            bool passwordUpdated = false;
            try
            {
                if ((await Validate(updateSalesPerson)) && (await GetSalesPersonBySalesPersonIDBL(updateSalesPerson.SalesPersonID)) != null)
                {
                    this.SalesPersonDAL.UpdateSalesPersonPasswordDAL(updateSalesPerson);
                    passwordUpdated = true;
                }
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return passwordUpdated;
        }


        /// <summary>
        /// Get the list of orders made by a salesperson.
        /// </summary>
        /// <param name="salesPersonID">Contains the Id of the salesperson who's saleIDs are required.</param>
        /// <returns>list of orders of salesperson.</returns>
        public async Task<List<Order>> GetSalesHistoryBL(Guid salesPersonID)
        {
            List<Order> sales = null;
            try
            {

                sales = await orderbl.GetOrderBySalesPersonIDBL(salesPersonID);

            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return sales;

        }

        /// <summary>
        /// Search order in the sales of a salesperson.
        /// </summary>
        /// <param name="searchSalesID">Contains the Id of the order to be searched.</param>
        /// <param name="salesPersonID">Contains the Id of the salesperson who's orders are to be searched.</param>
        /// <returns>Collection of salesIDs of salesperson.</returns>
        public async Task<Order> SearchSalesBL(Guid searchSalesID, Guid salesPersonID)
        {
            Order sale = null;
            List<Order> orderList = await orderbl.GetAllOrdersBL();
            try
            {
                await Task.Run(() =>
                {
                    sale = orderList.Find(
                     (item) => { return item.OrderID == searchSalesID && item.SalesPersonID == salesPersonID; }
                 );
                });
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return sale;

        }

        /// <summary>
        /// Add sales order by salesperson after sales visit.
        /// </summary>
        /// <param name="newOrder">Contains the Order details such OrderID,Amount etc. of the order to be added.</param>
        /// <param name="salesPersonID">Contains the Id of the salesperson who placed the order.</param>
        /// <returns>Determines whether order is added.</returns>
        public async Task<bool> AddSalesOrderBL(Order newOrder)
        {
            bool orderUploaded = false;
            try
            {
                bool orderAdded;
                Guid orderID;
                (orderAdded, orderID) = await orderbl.AddOrderBL(newOrder);
                if (orderAdded) // Add to list of orders placed
                    orderUploaded = true;

            }

            catch (GreatOutdoorsException ex)
            {
                throw ex;
            }

            return orderUploaded;
        }

        /// <summary>
        /// View orderID of requests made for offline sale.
        /// </summary>
        public async Task<List<Order>> ViewActiveOrdersBL()
        {
            List<Order> activeOrders = null;
            try
            {
                activeOrders = await orderbl.GetOrderForOfflineSaleBL();


            }


            catch (GreatOutdoorsException ex)
            {
                throw ex;
            }

            return activeOrders;
        }

        /// <summary>
        /// Add sales order by salesperson.
        /// </summary>
        /// <param name="activeOrderID">Contains the OrderID of order to be accepted.</param>
        /// <param name="salesPersonID">Contains the SalesPersonID of salesperson who accepts the order.</param>
        /// <returns>Determines whether order is accepted.</returns>
        public async Task<bool> AcceptOrderForSaleBL(Guid activeOrderID, Guid salesPersonID)
        {
            bool orderAccepted = false;
            Order matchingOrder = await orderbl.GetOrderByOrderIDBL(activeOrderID); // search for active order in the list of orders
            try
            {
                /*matchingOrder.CurrentStatus = Status.UnderProcessing*/;       // change status of order
                matchingOrder.SalesPersonID = salesPersonID;
                orderAccepted = await orderbl.UpdateOrderStatusBL(matchingOrder);  // update status of order


            }



            catch (GreatOutdoorsException ex)
            {
                throw ex;
            }
            return orderAccepted;
        }

        /// <summary>
        /// Modifies order details of the sales order.
        /// </summary>
        /// <param name="updatedOrder">Contains the OrderID of order to be accepted.</param>
        /// <returns>Determines whether order is modified.</returns>
        public async Task<bool> ModifySalesOrderBL(Order updatedOrder)
        {
            bool orderModified = false;
            Order matchingOrder = await orderbl.GetOrderByOrderIDBL(updatedOrder.OrderID);  // Search for the required order
            try
            {
                if (await orderbl.UpdateOrderBL(updatedOrder))       // update order
                    orderModified = true;

            }


            catch (GreatOutdoorsException ex)
            {
                throw ex;
            }

            return orderModified;
        }

        /// <summary>
        /// Confirm sales order.
        /// </summary>
        /// <param name="confirmOrderID">Contains the OrderID of confirmed order.</param>
        /// <param name="salesPersonID">Contains the salespersonID of salesperson who made the sale.</param>
        /// <returns>Determines whether order is modified.</returns>
        public async Task<bool> ConfirmSalesOrderBL(Guid confirmOrderID, Guid salesPersonID)
        {
            bool orderConfirmed = false;
            Order matchingOrder = await orderbl.GetOrderByOrderIDBL(confirmOrderID);
            //matchingOrder.CurrentStatus = Status.Delivered;
            matchingOrder.SalesPersonID = salesPersonID;
            try
            {
                if (await orderbl.UpdateOrderBL(matchingOrder))       // update order
                {
                    orderConfirmed = true;
                }
            }

            catch (GreatOutdoorsException ex)
            {
                throw ex;
            }

            return orderConfirmed;
        }


        /// <summary>
        /// Disposes DAL object(s).
        /// </summary>
        public void Dispose()
        {
            ((SalesPersonDAL)SalesPersonDAL).Dispose();
        }


    }
}



