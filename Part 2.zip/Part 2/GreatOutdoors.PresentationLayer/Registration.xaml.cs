﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Capgemini.GreatOutdoors.Contracts.BLContracts;
using Capgemini.GreatOutdoors.Contracts.DALContracts;
using GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.BusinessLayer;
using System.Text.RegularExpressions;

namespace GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for Registration.xaml
    /// </summary>
    public partial class Registration : Window
    {
        public Registration()
        {
            InitializeComponent();
        }
        private void Reset_Click(object sender, RoutedEventArgs e)
        {
            Reset();
        }
        public void Reset()
        {
            textBoxRetailerName.Text = "";
            textBoxRetailerMobile.Text = "";
            textBoxEmail.Text = "";
            textBoxRetailerPassword.Text = "";

        }


        private void Login_Click(object sender, RoutedEventArgs e)
        {
            //Login login = new Login();
            //login.Show();
            Close();
        }
        public async Task RetailerRegistration(object sender, RoutedEventArgs e)
        {
            if (textBoxRetailerName.Text.Length == 0)
            {

                MessageBox.Show("Enter Name.");

                textBoxEmail.Focus();
            }
            else if (!Regex.IsMatch(textBoxRetailerName.Text, @"/^[a-zA-Z][a-zA-Z\\s]+$/"))
            {

                MessageBox.Show("Enter a valid Name.");
                textBoxRetailerName.Select(0, textBoxRetailerName.Text.Length);
                textBoxRetailerName.Focus();
            }

            else if (textBoxEmail.Text.Length == 0)
            {

                MessageBox.Show("Enter an email.");

                textBoxEmail.Focus();
            }
            else if (!Regex.IsMatch(textBoxEmail.Text, @"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"))
            {

                MessageBox.Show("Enter a valid email.");
                textBoxEmail.Select(0, textBoxEmail.Text.Length);
                textBoxEmail.Focus();
            }
            else
            {
                try
                {
                    //Read inputs
                    Retailer retailer = new Retailer();

                    retailer.RetailerName = textBoxRetailerName.Text;

                    retailer.RetailerMobile = textBoxRetailerMobile.Text.ToString();

                    retailer.Email = textBoxEmail.Text.ToString();

                    retailer.RetailerPassword = textBoxRetailerPassword.Text.ToString();



                    using (IRetailerBL retailerBL = new RetailerBL())
                    {
                        bool isAdded = await retailerBL.AddRetailerBL(retailer);
                        if (isAdded)
                        {

                            MessageBox.Show("Retailer Added");

                        }
                    }
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }
            }


            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();


        }


    }
}
