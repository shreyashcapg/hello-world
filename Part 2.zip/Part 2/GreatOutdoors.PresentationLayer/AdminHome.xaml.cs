﻿using Capgemini.GreatOutdoors.BusinessLayer;
using GreatOutdoors.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for AdminHome.xaml
    /// </summary>
    public partial class AdminHome : Window
    {
        public AdminHome()
        {
            InitializeComponent();
            AdminDetials();
        }

        private async void AdminDetials()
        {
            Admin admin = new Admin();
            AdminBL adminBL = new AdminBL();
            admin = await adminBL.GetAdminByEmailAndPasswordBL(UserType.Email, UserType.Password);
            lblAdminName.Content = admin.AdminName;
            lblEmail.Content = admin.Email;
        }

        private void MenuItem_Click_Retailer(object sender, RoutedEventArgs e)
        {
            //Window window = new AddRetailer();
        }

        private void MenuItem_Click_SalesPerson(object sender, RoutedEventArgs e)
        {
            //Window window = new AddSalesPerson();
        }

        private void MenuItem_Click_AdminHome(object sender, RoutedEventArgs e)
        {
            AdminHome adminHomeWindow = new AdminHome();
            adminHomeWindow.Show();
            this.Close();
        }

        private void Button_Click_UpdateAdmin(object sender, RoutedEventArgs e)
        {
            UpdateAdmin updateAdminwindow = new UpdateAdmin();
            updateAdminwindow.Show();
            this.Close();
        }

        private void MenuItem_Click_Logout(object sender, RoutedEventArgs e)
        {
            MainWindow login = new MainWindow();
            login.Show();
            this.Close();
        }
    }
}
