﻿using Capgemini.GreatOutdoors.BusinessLayer;
using GreatOutdoors.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for AddressHome.xaml
    /// </summary>
    public partial class AddressHome : Window
    {
        public AddressHome()
        {
            InitializeComponent();
            fillData();
        }

        private async void fillData()
        { 
            List<Address> addresses = new List<Address>();
            AddressBL addressBL = new AddressBL();
            Retailer retailer = new Retailer();
            RetailerBL retailerBL = new RetailerBL();
            retailer = await retailerBL.GetRetailerByEmailAndPasswordBL(UserType.Email, UserType.Password);
            addresses = await addressBL.GetAddressByRetailerIDBL(retailer.RetailerID);

            dtgAddresses.ItemsSource = addresses;
        }

        private void MenuItem_Click_RetailerHome(object sender, RoutedEventArgs e)
        {
            //Retailer Home page
        }

        private void MenuItem_Click_ReturnOrder(object sender, RoutedEventArgs e)
        {

        }

        private void MenuItem_Click_PlaceOrder(object sender, RoutedEventArgs e)
        {

        }
        
        private void MenuItem_Click_OrderHistory(object sender, RoutedEventArgs e)
        {

        }
        private void MenuItem_Click_AddAddress(object sender, RoutedEventArgs e)
        {
            AddAddress addAddress = new AddAddress();
            addAddress.Show();
        }

        Guid ID;
    
        private void clickAddress(object sender, SelectionChangedEventArgs e)
        {

            int rowindex = dtgAddresses.SelectedIndex;
            if (rowindex < 0) { return; }
            ID = Guid.Parse(getCellData(dtgAddresses, rowindex, 0));           
            Window nt = new UpdateAddress(ID);
            nt.Show();
            this.Close();            
        }
        private string getCellData(DataGrid dg, int rowindex, int cellindex)
        {
            DataGridRow drow = dg.ItemContainerGenerator.ContainerFromIndex(rowindex) as DataGridRow;
            var cellContent = dg.Columns[cellindex].GetCellContent(drow) as TextBlock;
            return cellContent.Text;

        }
    }
}
