﻿using Capgemini.GreatOutdoors.BusinessLayer;
using GreatOutdoors.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for UpdateAdmin.xaml
    /// </summary>
    public partial class UpdateAdmin : Window
    {
        public UpdateAdmin()
        {
            InitializeComponent();
        }

        private async void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Admin admin = new Admin();
            AdminBL adminBL = new AdminBL();
            admin = await adminBL.GetAdminByEmailAndPasswordBL(UserType.Email, UserType.Password);
            Task<bool> adminCheck;
            if (admin.Email == UserType.Email)
            {
                admin.AdminName = tbxAdminName.Text;
                admin.Email = tbxEmail.Text;
                adminCheck = adminBL.UpdateAdminBL(admin);

                if (adminCheck.Equals(true))
                {
                    UserType.Email = admin.Email;
                    UserType.Password = admin.Password;
                    MessageBox.Show("Updated Succusfully!!");
                    UpdateAdmin updateAdmin = new UpdateAdmin();
                    updateAdmin.Show();
                }

                if (adminCheck.Equals(false))
                {
                    MessageBox.Show("Details not updated");
                }
            }
        }
    }
}
