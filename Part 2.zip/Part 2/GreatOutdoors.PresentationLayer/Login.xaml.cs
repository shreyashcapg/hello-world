﻿using GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.BusinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private async Task login_ClickAsync(object sender, RoutedEventArgs e)
        {
            
            ComboBoxItem typeItem = (ComboBoxItem)cbxUser.SelectedItem;
            string value = typeItem.Content.ToString();
            if (value == "Admin")
            {
                AdminBL adminBL = new AdminBL();
                Admin admin = await adminBL.GetAdminByEmailAndPasswordBL(tbxEmail.ToString(), tbxPassword.ToString());
                
                if (admin != null)
                {
                    UserType.Email = admin.Email;
                    UserType.Password = admin.Password;
                    AdminHome window = new AdminHome();

                }
            }

            if (value == "Sales Person")
            {
                SalesPersonBL salesPersonBL = new SalesPersonBL();
                SalesPerson salesPerson = await salesPersonBL.GetSalesPersonByEmailAndPasswordBL(tbxEmail.ToString(), tbxPassword.ToString());

                if (salesPerson != null)
                {
                    UserType.Email = salesPerson.Email;
                    UserType.Password = salesPerson.Password;
                    //Window window = new SalesPersonHome();
                }
            }

            if (value == "Retailer")
            {
                RetailerBL retailerBL = new RetailerBL();
                Retailer retailer = await retailerBL.GetRetailerByEmailAndPasswordBL(tbxEmail.ToString(), tbxPassword.ToString());

                if (retailer != null)
                {
                    UserType.Email = retailer.Email;
                    UserType.Password = retailer.RetailerPassword;
                    //Window window = new RetailerHome();
                }
            }
        }
    }
}
