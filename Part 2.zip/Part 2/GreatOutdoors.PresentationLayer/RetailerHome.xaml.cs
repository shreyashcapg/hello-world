﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.BusinessLayer;

namespace GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for RetailerHome.xaml
    /// </summary>
    public partial class RetailerHome : Window
    {
        public RetailerHome()
        {
            InitializeComponent();
        }


        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {


            Retailer retailer = new Retailer();
            RetailerBL retailerBL = new RetailerBL();

            retailer = await retailerBL.GetRetailerByEmailAndPasswordBL(UserType.Email, UserType.Password);

            textBoxRetailerName2.Text = retailer.RetailerName;

            textBoxRetailerMobile2.Text = retailer.RetailerMobile;

            textBoxEmail2.Text = retailer.Email;



        }

        private async void UpdateDetails(object sender, RoutedEventArgs e)
        {

            Retailer updateRetailer = new Retailer();
            RetailerBL updateRetailerBL = new RetailerBL();


            updateRetailer.RetailerName = textBoxRetailerName2.Text;

            updateRetailer.RetailerMobile = textBoxRetailerMobile2.Text;

            updateRetailer.Email = textBoxEmail2.Text;

            await updateRetailerBL.UpdateRetailerBL(updateRetailer);

        }

        private void MenuItem_Click_RetailerHome(object sender, RoutedEventArgs e)
        {

        }

        private void MenuItem_Click_PlaceOrder(object sender, RoutedEventArgs e)
        {

        }

        private void MenuItem_Click_AddressHome(object sender, RoutedEventArgs e)
        {
            AddressHome addressHome = new AddressHome();
            addressHome.Show();
            this.Close();
        } 
        
        private void MenuItem_Click_ReturnCancelOrder(object sender, RoutedEventArgs e)
        {

        }

        private void MenuItem_Click_Logout(object sender, RoutedEventArgs e)
        {
            MainWindow login = new MainWindow();
            login.Show();
        }
    }
}
