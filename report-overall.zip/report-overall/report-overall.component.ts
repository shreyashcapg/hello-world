import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ProductsService } from 'src/app/Services/products.service';
import { OrderDetailsService } from 'src/app/Services/orders.service';
import { Product } from 'src/app/Models/Product';
import { OrderDetail } from 'src/app/Models/order';

@Component({
  selector: 'report-overall',
  templateUrl: './report-overall.component.html',
  styleUrls: ['./report-overall.component.scss']
})

export class ReportOverAllComponent implements OnInit {
  profitReport: ProfitReport[] = []; 
  totalSellingPrice: number = 0;
  totalCostPrice: number = 0;
  totalQuantity: number = 0;
  productsList: Product[] = [];
  orderDetailsByProductList: OrderDetail[] = [];
  currentProductID: string;
  currentCostPrice: number;
  productWiseProfit: number;

  constructor(private productService: ProductsService, private orderDetailsService: OrderDetailsService) {

  }

  ngOnInit() {
    this.productService.GetAllProducts().subscribe((response) => {
      this.productsList = response;
    });
  }

  onGenerateReport() {

    for (var i = 0; i < this.productsList.length; i++) {
      this.currentProductID = this.productsList[i].productID;
      this.currentCostPrice = this.productsList[i].costPrice;
      this.orderDetailsService.GetOrderDetailsByProductID(this.currentProductID).subscribe((response) => {
        this.orderDetailsByProductList = response;
      });

      for (var k = 0; k < this.orderDetailsByProductList.length; k++) {

        if (this.orderDetailsByProductList[k].status != "InCart" || this.orderDetailsByProductList[k].status != "underProcessing" || this.orderDetailsByProductList[k].status != "Delivered" || this.orderDetailsByProductList[k].status != "Returned") {
          this.totalSellingPrice = this.totalSellingPrice + this.orderDetailsByProductList[k].totalPrice;
          this.totalQuantity += this.orderDetailsByProductList[k].quantity;
        }
      }

      this.totalCostPrice = this.currentCostPrice * this.totalQuantity;

      this.productWiseProfit = this.totalSellingPrice - this.totalCostPrice;
      this.profitReport[i] = new ProfitReport(this.currentProductID, this.totalQuantity, this.totalCostPrice, this.totalSellingPrice, this.productWiseProfit);
    }
  }
}

class ProfitReport
{
  productID: string;
  totalQuantitiesSold: number;
  costToCompany: number;
  sellingPrice: number;
  profitEarned: number;

  constructor(ProductId: string, TotalQuantitiesSold: number, CostToCompany: number, SellingPrice: number,
    ProfitEarned: number) {
    this.productID = ProductId;
    this.totalQuantitiesSold = TotalQuantitiesSold;
    this.costToCompany = CostToCompany;
    this.sellingPrice = SellingPrice;
    this.profitEarned = ProfitEarned;

  }
}
