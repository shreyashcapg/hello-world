﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using Capgemini.GreatOutdoors.BusinessLayer;
using Capgemini.GreatOutdoors.Exceptions;
using Capgemini.GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.Helpers;

using Capgemini.GreatOutdoors.Contracts.BLContracts;

namespace Capgemini.GreatOutdoors.PresentationLayer
{
    class Program
    {
        /// <summary>
        /// GreatOutdoors page
        /// </summary>
        /// <param name="args">Command line arguments</param>
        /// <returns></returns>
        
        public static async Task Main(string[] args)
        {
            try
            {

                WriteLine("=====================Great Outdoors=========================");
                int entryChoice = -2;

                do
                {
                    //Menu
                    WriteLine("\n1. Login");
                    WriteLine("2. Retailer Registration");
                    Write("Choice: ");

                    //Accept and check choice
                    bool isValidChoice = int.TryParse(ReadLine(), out entryChoice);
                    if (isValidChoice)
                    {
                        switch (entryChoice)
                        {
                            case 1: await Login(); break;
                            case 2: await RetailerRegistration(); break;
                            default: WriteLine("Invalid Choice"); break;
                        }
                    }
                    else
                    {
                        entryChoice = -2;
                    }
                } while (entryChoice != -1);

            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }

            WriteLine("Thank you!");
            ReadKey();
        }


        //
        public static async Task RetailerRegistration()
        {
            try
            {
                //Read inputs
                Retailer retailer = new Retailer();
                Write("Name: ");
                retailer.RetailerName = ReadLine();
                Write("Mobile Number: ");
                retailer.RetailerMobile = ReadLine();
                Write("Email: ");
                retailer.Email = ReadLine();
                Write("Password: ");
                retailer.Password = ReadLine();


                //Invoke AddSystemUserBL method to add
                using (IRetailerBL retailerBL = new RetailerBL())
                {
                    bool isAdded = await retailerBL.AddRetailerBL(retailer);
                    if (isAdded)
                    {
                        WriteLine("Retailer Added");
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }




        /// <summary>
        /// ///
        /// </summary>

        public static async Task Login()
        {
            //Invoke Login Screen
            int internalchoice = -2;
            (UserType userType, IUser currentUser) = await ShowLoginScreen();

            //Set current user details into CommonData (global data)
            CommonData.CurrentUser = currentUser;
            CommonData.CurrentUserType = userType;


            //Invoke User's Menu
            if (userType == UserType.Admin)
            {
                internalchoice= await AdminPresentation.AdminUserMenu();
            }
            else if (userType == UserType.Retailer)
            {
                internalchoice = await RetailerPresentation.RetailerMenu();
            }
            else if (userType == UserType.SalesPerson)
            {
                internalchoice = await SalesPersonPresentation.SalesPersonMenu();
            }
        }

        /// <summary>
        /// Login (based on Email and Password)
        /// </summary>
        /// <returns></returns>
        static async Task<(UserType, IUser)> ShowLoginScreen()
        {
            //Read inputs
            string email, password;
            WriteLine("=====LOGIN=========");
            Write("Email: ");
            email = ReadLine();
            Write("Password: ");
            password = ReadLine();

            using (IAdminBL adminBL = new AdminBL())
            {
                //Invoke GetAdminByEmailAndPasswordBL for checking email and password of Admin
                Admin admin = await adminBL.GetAdminByEmailAndPasswordBL(email, password);
                if (admin != null)
                {
                    return (UserType.Admin, admin);
                }
            }

            using (IRetailerBL retailerBL = new RetailerBL())
            {
                //Invoke GetRetailerByEmailAndPasswordBL for checking email and password of Admin
                Retailer retailer = await retailerBL.GetRetailerByEmailAndPasswordBL(email, password);
                if (retailer != null)
                {
                    return (UserType.Retailer, retailer);
                }
            }

            using (ISalesPersonBL salesPersonBL = new SalesPersonBL())
            {
                //Invoke GetSalesPersonByEmailAndPasswordBL for checking email and password of Admin
                SalesPerson salesPerson = await salesPersonBL.GetSalesPersonByEmailAndPasswordBL(email, password);
                if (salesPerson != null)
                {
                    return (UserType.SalesPerson, salesPerson);
                }
            }

            WriteLine("Invalid Email or Password. Please try again...");
            return (UserType.Anonymous, null);
        }

    }
}




