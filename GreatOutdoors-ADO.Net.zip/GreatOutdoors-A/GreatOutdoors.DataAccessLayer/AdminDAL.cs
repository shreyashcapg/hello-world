﻿using System;
using System.Collections.Generic;
using Capgemini.GreatOutdoors.Contracts.DALContracts;
using Capgemini.GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.Exceptions;
using Capgemini.GreatOutdoors.Helpers;
using System.Data.SqlClient;
using System.Data;

namespace GreatOutdoors.DataAccessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating, deleting admins from Admins collection.
    /// </summary>
    public class AdminDAL : AdminDALBase, IDisposable
    {
        SqlConnection sqlConn = new SqlConnection(Properties.Setting.Default.dbCon);

        /// <summary>
        /// Constructor for AdminDAL
        /// </summary>
        public AdminDAL()
        {
            Serialize();
            Deserialize();
        }

        /// <summary>
        /// Gets admin based on AdminID.
        /// </summary>
        /// <param name="searchAdminID">Represents AdminID to search.</param>
        /// <returns>Returns Admin object.</returns>
        public override Admin GetAdminByAdminIDDAL(Guid searchAdminID)
        {
            Admin matchingAdmin = null;
            try
            {
                sqlConn.Open();
                string query = "TeamA.Admin";
                SqlCommand cmd = new SqlCommand(query,sqlConn);

                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(cmd);
                DataSet dataSet = new DataSet();
                sqlDataAdapter.Fill(dataSet);
                DataRow dataRow;
                
                //Find Admin based on searchAdminID
                for(int i=0; i < dataSet.Tables[0].Rows.Count; ++i)
                {
                    dataRow = dataSet.Tables[0].Rows[i];
                    matchingAdmin.AdminID = (Guid)dataRow["AdminID"];
                    if(matchingAdmin.AdminID == searchAdminID)
                    {
                        matchingAdmin.AdminName = Convert.ToString(dataRow["AdminName"]);
                        matchingAdmin.Email = Convert.ToString(dataRow["Email"]);
                        matchingAdmin.Password = Convert.ToString(dataRow["Password"]);
                    }
                }
            }
            catch (GreatOutdoorsException)
            {
                throw new GreatOutdoorsException("Exception Fetched! Admin could't be found");
            }
            return matchingAdmin;
        }

        /// <summary>
        /// Gets admin based on Password.
        /// </summary>
        /// <param name="email">Represents Admin's Email Address.</param>
        /// <param name="password">Represents Admin's Password.</param>
        /// <returns>Returns Admin object.</returns>
        public override Admin GetAdminByEmailAndPasswordDAL(string email, string password)
        {
            Admin matchingAdmin = null;
            try
            {
                sqlConn.Open();
                string query = "TeamA.Admin";
                SqlCommand cmd = new SqlCommand(query,sqlConn);

                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(cmd);
                DataSet dataSet = new DataSet();
                sqlDataAdapter.Fill(dataSet);
                DataRow dataRow;
                
                //Find Admin based on searchAdminID
                for(int i=0; i < dataSet.Tables[0].Rows.Count; ++i)
                {
                    dataRow = dataSet.Tables[0].Rows[i];
                    matchingAdmin.Email = Convert.ToString(dataRow["Email"]);
                    matchingAdmin.Password = Convert.ToString(dataRow["Password"]);
                    if(matchingAdmin.Email == email && matchingAdmin.Password == password)
                    {
                        matchingAdmin.AdminName = Convert.ToString(dataRow["AdminName"]);
                        matchingAdmin.Email = Convert.ToString(dataRow["Email"]);
                        matchingAdmin.Password = Convert.ToString(dataRow["Password"]);
                    }
                }
            }
            catch (GreatOutdoorsException)
            {
                throw new GreatOutdoorsException("Exception Fetched! Admin could't be found");
            }
            return matchingAdmin;
        }

        /// <summary>
        /// Updates admin based on AdminID.
        /// </summary>
        /// <param name="updateAdmin">Represents Admin details including AdminID, AdminName etc.</param>
        /// <returns>Determinates whether the existing admin is updated.</returns>
        public override bool UpdateAdminDAL(Admin updateAdmin)
        {
            bool adminUpdated = false;
            try
            {
                //Find Admin based on AdminID
                Admin matchingAdmin = GetAdminByAdminIDDAL(updateAdmin.AdminID);

                if (matchingAdmin != null)
                {
                    if(matchingAdmin.AdminID == updateAdmin.AdminID)
                    {
                        sqlConn.Open();
                        string query = "TeamA.Admin";
                        SqlCommand cmd = new SqlCommand(query, sqlConn);

                        //Update address details
                        updateAdmin.LastModifiedDateTime = DateTime.Now;
                        

                        //Code to be added
                            cmd.ExecuteNonQuery();
                            addressUpdated = true;
                            break;
                        
                    }
                }
            }
            catch (GreatOutdoorsException)
            {
                throw new GreatOutdoorsException("Exception Fetched! Admin not updated.");
            }
            return adminUpdated;
        }

        /// <summary>
        /// Updates admin's password based on AdminID.
        /// </summary>
        /// <param name="updateAdmin">Represents Admin details including AdminID, Password.</param>
        /// <returns>Determinates whether the existing admin's password is updated.</returns>
        public override bool UpdateAdminPasswordDAL(Admin updateAdmin)
        {
            bool passwordUpdated = false;
            try
            {
                //Find Admin based on AdminID
                Admin matchingAdmin = GetAdminByAdminIDDAL(updateAdmin.AdminID);

                if (matchingAdmin != null)
                {
                    //Update admin details
                    ReflectionHelpers.CopyProperties(updateAdmin, matchingAdmin, new List<string>() { "Password" });
                    matchingAdmin.LastModifiedDateTime = DateTime.Now;

                    passwordUpdated = true;
                }
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return passwordUpdated;
        }

        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            sqlConn.Dispose();
        }
    }
}