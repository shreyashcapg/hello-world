﻿using System;
using System.Collections.Generic;
using Capgemini.GreatOutdoors.Exceptions;
using Capgemini.GreatOutdoors.Helpers;
using Capgemini.GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.Contracts.DALContracts;
using System.Data.SqlClient;
using System.Data;

namespace Capgemini.GreatOutdoors.DataAccessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating, deleting admins from Admins collection.
    /// </summary>
    public class AddressDAL : AddressDALBase, IDisposable
    {
        SqlConnection sqlConn = new SqlConnection(Properties.Setting.Default.dbCon);
        ///// <summary>
        ///// Constructor of AddressDAL
        ///// </summary>
        //public AddressDAL()
        //{
        //    Serialize();
        //    Deserialize();
        //}

        /// <summary>
        /// Adds new address to Address collection.
        /// </summary>
        /// <param name="newAddress">Contains the address details to be added.</param>
        /// <returns>Determinates whether the new address is added.</returns>
        public override (Guid, bool) AddAddressDAL(Address newAddress)
        {
            bool addressAdded = false;
            try
            {
                sqlConn.Open();
                newAddress.AddressID = Guid.NewGuid();
                newAddress.CreationDateTime = DateTime.Now;
                newAddress.LastModifiedDateTime = DateTime.Now;
                string query = "[13th Aug CLoud PT Immersive].TeamA.AddAddress";
                SqlCommand cmd = new SqlCommand(query, sqlConn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@AddressID", newAddress.AddressID);
                cmd.Parameters.AddWithValue("@RetailerID", newAddress.RetailerID);
                cmd.Parameters.AddWithValue("@Line1", newAddress.Line1);
                cmd.Parameters.AddWithValue("@Line2", newAddress.Line2);
                cmd.Parameters.AddWithValue("@Pincode", newAddress.Pincode);
                cmd.Parameters.AddWithValue("@City", newAddress.City);
                cmd.Parameters.AddWithValue("@State", newAddress.State);
                cmd.Parameters.AddWithValue("@MobileNo", newAddress.MobileNo);

                int rowsAffected = cmd.ExecuteNonQuery();
                if (rowsAffected == 1)
                    addressAdded = true;
                sqlConn.Close();
            }
            catch (GreatOutdoorsException)
            {
                throw new GreatOutdoorsException("Exception Occured!! New Address not Added.");
            }
            return (newAddress.AddressID, addressAdded);
        }
        /// <summary>
        /// Gets all addresses from the collection.
        /// </summary>
        /// <returns>Returns list of all distributors.</returns>
        public override List<Address> GetAllAddressDAL()
        {
            List<Address> addresses = new List<Address>();
            try
            {

                sqlConn.Open();

                string query = "TeamA.GetAllAddresses";
                SqlCommand cmd = new SqlCommand(query, sqlConn);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(cmd);
                DataSet dataSet = new DataSet();
                sqlDataAdapter.Fill(dataSet);

                DataRow row;
                Address address = new Address();
                for (int i = 0; i < dataSet.Tables[0].Rows.Count; ++i)
                {
                    row = dataSet.Tables[0].Rows[i];
                    address.AddressID = (Guid)row["AddressID"];
                    address.RetailerID = (Guid)row["RetailerID"];
                    address.Line1 = Convert.ToString(row["Line1"]);
                    address.Line2 = Convert.ToString(row["Line2"]);
                    address.Pincode = Convert.ToString(row["Pincode"]);
                    address.City = Convert.ToString(row["City"]);
                    address.State = Convert.ToString(row["State"]);
                    address.MobileNo = Convert.ToString(row["MobileNo"]);

                    addresses.Add(address);
                }
                sqlConn.Close();
            }
            catch (GreatOutdoorsException)
            {
                throw new GreatOutdoorsException("Exception Fetched!! Addresses couldn't be found.");
            }
            return addresses;
        }
        /// <summary>
        /// Gets distributor based on DistributorID.
        /// </summary>
        /// <param name="searchAddressID">Represents DistributorID to search.</param>
        /// <returns>Returns Distributor object.</returns>
        public override List<Address> GetAddressByRetailerIDDAL(Guid searchRetailerID)
        {
            List<Address> matchingAddress = new List<Address>();
            try
            {
                sqlConn.Open();
                string query = "TeamA.GetAddressByRetailerIDDAL";
                SqlCommand cmd = new SqlCommand(query, sqlConn);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(cmd);
                DataSet dataSet = new DataSet();
                sqlDataAdapter.Fill(dataSet);

                DataRow dataRow;
                Address address = new Address();
                for (int i = 0; i < dataSet.Tables[0].Rows.Count; ++i)
                {
                    dataRow = dataSet.Tables[0].Rows[i];
                    address.RetailerID = (Guid)dataRow["RetailerID"];
                    if (address.RetailerID == searchRetailerID)
                    {
                        address.AddressID = (Guid)dataRow["AddressID"];
                        address.Line1 = Convert.ToString(dataRow["Line1"]);
                        address.Line2 = Convert.ToString(dataRow["Line2"]);
                        address.Pincode = Convert.ToString(dataRow["Pincode"]);
                        address.City = Convert.ToString(dataRow["City"]);
                        address.State = Convert.ToString(dataRow["State"]);
                        address.MobileNo = Convert.ToString(dataRow["MobileNo"]);

                        matchingAddress.Add(address);
                    }
                }
            }
            catch (GreatOutdoorsException)
            {
                throw new GreatOutdoorsException("Exception Fetched!! Adddress Not Found.");
            }
            return matchingAddress;
        }


        /// <summary>
        /// Updates address based on AddressID.
        /// </summary>
        /// <param name="updateAddress">Represents Address details including AddressID, Line1, etc.</param>
        /// <returns>Determinates whether the existing address is updated.</returns>
        public override (Guid, bool) UpdateAddressDAL(Address updateAddress)
        {
            bool addressUpdated = false;
            try
            {
                //Find address based on AddressID
                List<Address> matchingAddress = GetAddressByRetailerIDDAL(updateAddress.RetailerID);

                if (matchingAddress != null)
                {
                    foreach(var item in matchingAddress)
                    {
                        if(item.AddressID == updateAddress.AddressID)
                        {
                            sqlConn.Open();

                            string query = "TeamA.UpdateAddress";
                            SqlCommand cmd = new SqlCommand(query, sqlConn);
                            cmd.CommandType = CommandType.StoredProcedure;

                            //Update address details
                            updateAddress.LastModifiedDateTime = DateTime.Now;

                            cmd.Parameters.AddWithValue("@RetailerID", updateAddress.RetailerID);
                            cmd.Parameters.AddWithValue("@Line1", updateAddress.Line1);
                            cmd.Parameters.AddWithValue("@Line2", updateAddress.Line2);
                            cmd.Parameters.AddWithValue("@Pincode", updateAddress.Pincode);
                            cmd.Parameters.AddWithValue("@City", updateAddress.City);
                            cmd.Parameters.AddWithValue("@State", updateAddress.State);
                            cmd.Parameters.AddWithValue("@MobileNo", updateAddress.MobileNo);
                            cmd.Parameters.AddWithValue("@LastModifiedDate", updateAddress.LastModifiedDateTime);
                            cmd.ExecuteNonQuery();
                            addressUpdated = true;
                            break;
                        }
                    }
                }
            }
            catch (GreatOutdoorsException)
            {
                throw new GreatOutdoorsException("Exception Fetched! Address not updated.");
            }
            return (updateAddress.AddressID,addressUpdated);

        }

        /// <summary>
        /// Deletes address based on AddressID.
        /// </summary>
        /// <param name="deleteAddressID">Represents AddressID to delete.</param>
        /// <returns>Determinates whether the existing address is updated.</returns>
        public override bool DeleteAddressDAL(Guid deleteAddressID)
        {
            bool addressDeleted = false;            
            string query;
            try
            {
                sqlConn.Open();
                query = "TeamA.DeleteAddress";
                SqlCommand cmd = new SqlCommand(query, sqlConn);
                cmd.CommandType = CommandType.StoredProcedure;
                
                //Find Address based on searchAddressID
                cmd.Parameters.AddWithValue("@AddressID", deleteAddressID).DbType = DbType.Guid;
                cmd.ExecuteNonQuery();

                addressDeleted = true;
            }
            catch (GreatOutdoorsException)
            {
                throw new GreatOutdoorsException("Exception Fetched! Address not deleted.");
            }
            return addressDeleted;

        }

        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            sqlConn.Dispose();
        }
    }
}
