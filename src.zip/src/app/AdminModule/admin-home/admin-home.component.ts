import { Component, OnInit } from '@angular/core';
import { Admin } from '../../Models/admin';
import { AdminService } from '../../Services/admin.service';
//import { PecuniaComponentBase } from 'src/app/pecunia-component';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import * as $ from "jquery";

@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.scss']
})
export class AdminHomeComponent implements OnInit {

  admins: Admin[] = [];
  showAdminSpinner: boolean = false;
  viewAdminCheckBoxes: any;

  editAdminForm: FormGroup;
  editAdminDisabled: boolean = false;
  editAdminFormErrorMessages: any;

  constructor(private adminService: AdminService) {

    this.editAdminForm = new FormGroup({
      id: new FormControl(1),
      adminID: new FormControl('123'),
      adminName: new FormControl(null, [Validators.required, Validators.minLength(2), Validators.maxLength(40)]),
      email: new FormControl(null, [Validators.required, Validators.email]),
      password: new FormControl(null)
    });

    this.editAdminFormErrorMessages = {
      adminName: { required: "Employee Name can't be blank", minlength: "Employee Name should contain at least 2 characters", maxlength: "Employee Name can't be longer than 40 characters" },
      email: { required: "Email can't be blank", pattern: "Email is invalid" }
    };

    this.viewAdminCheckBoxes = {
      adminName: true,
      email: true,
      lastModifiedOn: true
    };

  }

  ngOnInit() {
    this.showAdminSpinner = true;
    this.adminService.GetAllAdmins().subscribe((response) => {
      this.admins = response;
      this.showAdminSpinner = false;
      console.log(response);
    }, (error) => {
      console.log(error);
    })
  }

  getFormControlCssClass(formControl: FormControl, formGroup: FormGroup): any {
    return {
      'is-invalid': formControl.invalid && (formControl.dirty || formControl.touched || formGroup["submitted"]),
      'is-valid': formControl.valid && (formControl.dirty || formControl.touched || formGroup["submitted"])
    };
  }

  getCanShowFormControlErrorMessage(formControlName: string, validationProperty: string, formGroup: FormGroup): boolean {
    return formGroup.get(formControlName).invalid && (formGroup.get(formControlName).dirty || formGroup.get(formControlName).touched || formGroup['submitted']) && formGroup.get(formControlName).errors[validationProperty];
  }

  onEditAdminlick(index) {
    this.editAdminForm.reset();
    this.editAdminForm["submitted"] = false;
    this.editAdminForm.patchValue({
      id: this.admins[index].id,
      adminID: this.admins[index].adminID,
      adminName: this.admins[index].adminName,
      email: this.admins[index].email,
      password: this.admins[index].password
    });
  }

  onUpdateAdminClick(event) {
    this.editAdminForm["submitted"] = true;
    if (this.editAdminForm.valid) {
      this.editAdminDisabled = true;
      var admin: Admin = this.editAdminForm.value;

      this.adminService.UpdateAdmin(admin).subscribe((updateResponse) => {
        this.editAdminForm.reset();
        $("#btnUpdateEmployeeCancel").trigger("click");
        this.editAdminDisabled = false;
        this.showAdminSpinner = true;

        this.adminService.GetAllAdmins().subscribe((getResponse) => {
          this.showAdminSpinner = false;
          this.admins = getResponse;
        }, (error) => {
          console.log(error);
        });
      },
        (error) => {
          console.log(error);
          this.editAdminDisabled = false;
        });
    }
    
  }


}
