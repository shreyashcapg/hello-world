import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Admin } from '../Models/admin';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  constructor(private httpClient: HttpClient) {

  }

  UpdateAdmin(admin: Admin): Observable<boolean> {
    admin.lastModifiedDateTime = new Date().toLocaleDateString();
    return this.httpClient.put<boolean>(`/api/admins`, admin);
  }

  GetAllAdmins(): Observable<Admin[]> {
    return this.httpClient.get<Admin[]>(`/api/admins`);
  }

}
