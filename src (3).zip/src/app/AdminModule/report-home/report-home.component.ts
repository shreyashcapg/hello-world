import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-home',
  templateUrl: './report-home.component',
  styleUrls: ['./report-home.component.scss',]
})

export class ReportHomeComponent implements OnInit {

  constructor() {

  }

  ngOnInit() {

  }
}
