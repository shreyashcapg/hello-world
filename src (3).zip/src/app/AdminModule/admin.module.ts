import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AdminRoutingModule } from './admin-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { ReportHomeComponent } from './report-home/report-home.component';

@NgModule({
  declarations: [
    AdminHomeComponent,
    ReportHomeComponent
    //ReportComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AdminRoutingModule,
    HttpClientModule
  ],
  exports: [
    AdminRoutingModule,
    AdminHomeComponent,
    ReportHomeComponent
    //SuppliersComponent
  ]
})
export class AdminModule { }

